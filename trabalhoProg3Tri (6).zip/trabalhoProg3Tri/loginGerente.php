<?php
if(isset($_POST['botao'])){
    require_once __DIR__."/vendor/autoload.php";
    $g = new Gerente($_POST['user'],$_POST['senha']);
    if($g->authenticate()){
        header("location: indexGerente.php");
    }else{
        header("location: loginGerente.php");
    }
}
?>

<!DOCTYPE html>
<html lang="pt-br">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
	<title>Login Gerente</title>
	<link rel="shortcut icon" href="icon.png" />
	<link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.11.2/font/bootstrap-icons.min.css">
    <style>
        
@import url('https://fonts.googleapis.com/css?family=Montserrat:400,800');

* {
	box-sizing: border-box;
}

body {
    background: #f6f5f7;
	display: flex;
    justify-content: center;
    align-items: center;
    flex-direction: column;
    font-family: 'Montserrat', sans-serif;
    height: 100vh;
    margin: -20px 0 50px;
    }

h1 {
	font-weight: bold;
	margin: 0;
}

h2 {
	text-align: center;
}

p {
	font-size: 14px;
	font-weight: 100;
	line-height: 20px;
	letter-spacing: 0.5px;
	margin: 20px 0 30px;
}


a {
	color: #333;
	font-size: 14px;
	text-decoration: none;
	margin: 15px 0;
}

.botao {
	border-radius: 20px;
	border: 1px solid #ce2bff;
	background-color: #7B1E83;
	color: #FFFFFF;
	font-size: 12px;
	font-weight: bold;
	padding: 12px 45px;
	letter-spacing: 1px;
	text-transform: uppercase;
}

form {
	background-color: #FFFFFF;
	display: flex;
	flex-direction: column;
    padding: 50px 50px;
    height: 100%;
	text-align: center;
	justify-content: center;
	align-items: center;
}

input {
	background-color: #eee;
	border: none;
	padding: 12px 15px;
	margin: 8px 0;
	width: 100%;
}

.container {
	background-color: #fff;
	border-radius: 10px;
  	box-shadow: 0 14px 28px rgba(0,0,0,0.25), 
			0 10px 10px rgba(0,0,0,0.22);
	position: relative;
	overflow: hidden;
	width: 400px;
	max-width: 100%;
	min-height: 480px;
}

.form-container {
	top: 0;
	height: 100%; 
    
}
img{
	width: 90%;
}
#icon{
	width: 40%;
}
.senha input{
            flex-grow: 1;

        }
.login{
            position: relative;
            display: flex;
            align-items: center;
			flex-direction: column;
        }
.senha i{
            font-size: 20px;
            cursor: pointer;
            position: absolute;
			align-items: center;
            right: 5%;
			top: 42%;
            color: #808080;
        }
</style>
</head>
<body>
    <div class="container">
        <div class="form-container">
            <form action='loginGerente.php' method='post'>
				<img id = "icon" src="icon.png">
				<h1>Faça Login</h1>
				<div class="login">
                <input type="text" placeholder="User" name="user">
				<div class="senha">
                	<input type="password" placeholder="Senha" id="senha" name="senha">
					<i class='bi bi-eye' id='iconSenha' onclick='mostrarSenha()'></i>
				</div>
                <input type="submit" class="botao" name="botao" value="Enviar">
				</div>
            </form>
        </div>
    </div>
<script>
		function mostrarSenha(){
            var inputPass = document.getElementById('senha');
            var btnShowPass = document.getElementById('iconSenha');
            
            if(inputPass.type === 'password'){
                inputPass.setAttribute('type','text');
                btnShowPass.classList.replace('bi-eye','bi-eye-slash');
            }else{
                inputPass.setAttribute('type','password');
                btnShowPass.classList.replace('bi-eye-slash','bi-eye');
            }
        }
</script>
    
</body>
</html>
   