<?php
session_start();

if (!isset($_SESSION['id'])) {
    require_once __DIR__."/vendor/autoload.php";
    header("location:loginuser.php");
} else {
    require_once __DIR__."/vendor/autoload.php";
    $usuario = Usuario::find($_SESSION['id']);
}

if (isset($_POST['botao'])) {
    require_once __DIR__."/vendor/autoload.php";

    // Retrieve the user from the database
    $usuario = Usuario::find($_SESSION['id']);

    // Update only if a new name is provided
    if (!empty($_POST['nome'])) {
        $usuario->setNome($_POST['nome']);
    }

    // Update only if a new password is provided
    if (!empty($_POST['senha'])) {
        $usuario->setSenha($_POST['senha']);
    }

    // Save the changes
    $usuario->save();

    header("location: PaginainicialUser.php");
}
?>
<!DOCTYPE html>
<html lang="pt-br"></html>
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Editar Conta</title>
    <link rel="shortcut icon" img href="icon.png" />
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.11.2/font/bootstrap-icons.min.css">
    <style>
    @import url('https://fonts.googleapis.com/css?family=Montserrat:400,800');

        * {
            box-sizing: border-box;
        }

        body {
            background: #f6f5f7;
            display: flex;
            justify-content: center;
            align-items: center;
            flex-direction: column;
            font-family: 'Montserrat', sans-serif;
            height: 100vh;
            margin: -20px 0 50px;
        }
        
        .button {
            border-radius: 20px;
            border: 1px solid #ce2bff;
            background-color: #7B1E83;
            color: #FFFFFF;
            font-size: 12px;
            font-weight: bold;
            padding: 12px 45px;
           
        }

        form {
            background-color: #FFFFFF;
            padding: 50px 50px;
            height: 100%;
        }

        input {
            background-color: #eee;
            border: none;
            padding: 12px 15px;
            margin: 8px 0;
            width: 100%;
        }

        .container {
            background-color: #fff;
            border-radius: 10px;
            box-shadow: 0 14px 28px rgba(0,0,0,0.25), 
                    0 10px 10px rgba(0,0,0,0.22);
            position: relative;
            overflow: hidden;
            width: 400px;
            max-width: 100%;
            height: auto;
        }

        #menu {
            width: 80px;
            height: 100%;
            position: fixed;
            top: 0;
            left: 0;
            background-color: #f6f5f7;
            color: #7B1E83;
            overflow-x: hidden;
            transition: 0.5s;
            display: flex;
            flex-direction: column;
            align-items: center;
            justify-content: space-between;
        }

        #menu a {
            text-decoration: none;
            font-size: 16px;
            color: #7B1E83;
            display: flex;
            align-items: center;
            padding: 15px 0;
            transition: 0.3s;
        }

        #menu a:hover {
            border-radius: 40px;
            color: #f6f5f7;
            background-color: #7B1E83;
            padding: 12px;
        }

        #menu i {
            font-size: 24px;
            margin-bottom: 5px;
            margin-right: 8px;
            margin-left: 8px;
        }

        #menu span {
            display: none;
        }

        #menu:hover span {
            display: block;
        }

        .senha input{
            flex-grow: 1;

        }
        .alteraSenha{
            position: relative;
            display: flex;
            align-items: center;
        }
        .alteraSenha i{
            font-size: 20px;
            cursor: pointer;
            position: absolute;
            right: 5%;
            top: 38%;
            color: #808080;
        }

        #btnAlterarSenha{
            margin:20px;
            margin-left: 0px;
            border-radius: 20px;
            border: 1px solid #ce2bff;
            background-color: #ce2bff;
            color: #FFFFFF;
            font-size: 12px;
            font-weight: bold;
            padding: 8px 30px;
        }
        
    </style>
</head>
<body>
<div id="menu">
        <a href="PaginaInicialUser.php">
            <i class="fa fa-home"></i>
            <span>Página Inicial</span>
        </a>
        <a href="rankingUser.php">
        <i class="bi bi-bar-chart-fill"></i>
        <span>Ranking</span>
        </a>
        <a href="editarContaUser.php">
        <i class="bi bi-pen-fill"></i>            
        <span>Editar conta</span>
        </a>
        <a href="logoutUser.php">
            <i class="fa fa-sign-out"></i>
            <span>Sair</span>
        </a>
    </div>
    <div class="container">

    <form action='editarContaUser.php' method='POST' enctype="multipart/form-data" id="formEditarConta">
        <?php
            echo "Nome: <input name='nome' value='{$usuario->getNome()}' type='text'>";
            echo "<br>";
        ?>

        <button type="button" id="btnAlterarSenha">Alterar Senha</button>

        <div class="alteraSenha" name="btnSenha" style="display: none;">
            <?php
                echo "Senha:";
                echo"<div name='senha' class='senha'>";
                echo "<input name='senha' type='password' id='senha'>";
                echo "<i class='bi bi-eye' id='iconSenha' onclick='mostrarSenha()'></i>"; 
                echo "</div>";
                echo "<br>";
                //echo "Confirmar senha: <input name='confSenha' type='password'>";
            ?>
        </div>

        <?php 
            echo "<input type='submit' class='button' name='botao'>"; 
        ?>
    </form>

    
    
    </div>
    <script>
        const menu = document.getElementById("menu");

        menu.addEventListener("mouseenter", () => {
            menu.style.width = "250px";
        });

        menu.addEventListener("mouseleave", () => {
            menu.style.width = "80px";
        });



        //botao alterar conta
        var btnAlterarSenha = document.getElementById("btnAlterarSenha");
        var divSenha = document.querySelector(".alteraSenha");

        btnAlterarSenha.addEventListener("click", function () {
            if (divSenha.style.display === "none" || divSenha.style.display === "") {
                divSenha.style.display = "block";
            } else {
                divSenha.style.display = "none";
            }
        });

        // Vizualizar senha 
        function mostrarSenha(){
            var inputPass = document.getElementById('senha');
            var btnShowPass = document.getElementById('iconSenha');
            
            if(inputPass.type === 'password'){
                inputPass.setAttribute('type','text');
                btnShowPass.classList.replace('bi-eye','bi-eye-slash');
            }else{
                inputPass.setAttribute('type','password');
                btnShowPass.classList.replace('bi-eye-slash','bi-eye');
            }
        }

    </script>
</body>
</html>