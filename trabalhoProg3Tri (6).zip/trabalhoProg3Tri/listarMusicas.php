<?php
session_start();
if(!isset($_SESSION['id'])){
    header("location:loginGerente.php");
}
require_once __DIR__."/vendor/autoload.php";

//$musicas = Musica::findall($_GET['id']);
$musicas = isset($_GET['id']) ? Musica::findall($_GET['id']) : Musica::findall();

?>
<!DOCTYPE html>
<html lang="pt-br">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Listagem de Musicas</title>
    <link rel="shortcut icon" href="icon.png" />
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">
    <link rel="stylesheet" href="https://fonts.googleapis.com/css2?family=Material+Symbols+Outlined:opsz,wght,FILL,GRAD@20..48,100..700,0..1,-50..200" />
    <style>

        @import url('https://fonts.googleapis.com/css?family=Montserrat:400,800');

        body {
            background-color: #f6f5f7;
            font-family: 'Montserrat', sans-serif;
            margin: 0;
            padding: 0;
            
        }

        .container {
            display: flex;
            flex-wrap: wrap;
            justify-content: center;
            align-items: center;
            min-height: 100vh;
            padding: 10px;
        }

        #menu {
            width: 80px;
            height: 100%;
            position: fixed;
            top: 0;
            left: 0;
            background-color: #f6f5f7;
            color: #7B1E83;
            overflow-x: hidden;
            transition: 0.5s;
            display: flex;
            flex-direction: column;
            align-items: center;
            justify-content: space-between;
        }

        #menu a {
            text-decoration: none;
            font-size: 16px;
            color: #7B1E83;
            display: flex;
            align-items: center;
            padding: 15px 0;
            transition: 0.3s;
        }

        #menu a:hover {
            border-radius: 40px;
            color: #f6f5f7;
            background-color: #7B1E83;
            padding: 12px;
        }

        #menu i {
            font-size: 24px;
            margin-bottom: 5px;
            margin-right: 8px;
            margin-left: 8px;
        }

        #menu span {
            display: none;
        }

        #menu:hover span {
            display: block;
        }

        

.card {
    width: 800px;
    padding: 20px;
    margin: 40px;
    box-shadow: 0 4px 6px rgba(0, 0, 0, 0.1);
    background-color: #ffffff;
    font-family: 'Montserrat', sans-serif;
    border-radius: 10px;
    transition: all 0.3s ease;
}

.card img {
    width: 16%;
    height: auto;
    object-fit: cover;
    align-content: center;
    border-radius: 5px;
}

.listar {
    display: flex;
    background-color: #f6f5f7;
    border-radius: 10px;
    margin: 5px;
}

.infossemimg {
    width: 100%;
    height: auto;
    display: flex;
    justify-content: space-between;
    padding: 8px;
}

.infos {
    flex: 1;
}

.editex {
    display: flex;
    flex-direction: column;
    align-items: flex-end;
    
}

.btnf{
    width: 80px;
    height: 15px;
    border-radius: 5px;

}

.music-app {
    background-color: #1a1a1a;
    color: #ffffff;
    width: 100%;
    max-width: 1000px;
    padding: 20px;
    border-radius: 10px;
    box-shadow: 0 4px 6px rgba(0, 0, 0, 0.1);
}

.music-list {
    display: grid;
    grid-template-columns: repeat(auto-fit, minmax(300px, 1fr));
    grid-gap: 20px;
}

.music {
    background-color: #1a1a1a;
    color: #ffffff;
    padding: 20px;
    border-radius: 10px;
    box-shadow: 0 4px 6px rgba(0, 0, 0, 0.1);
}

.btnf {
  display: inline-block;
  padding: 8px 16px; 
  font-size: 14px;
  text-align: center;
  text-decoration: none;
  cursor: pointer;
  border: 2px solid #7B1E83; 
  border-radius: 5px;
  color: #7B1E83; 
  background-color: white;
  transition: background-color 0.3s, color 0.3s;
}


.btnf:hover {
  background-color: #7B1E83; 
  color: white;
}

.material-symbols-outlined {
  font-variation-settings:
  'FILL' 0,
  'wght' 260,
  'GRAD' 0,
  'opsz' 8
}
</style>
</head>
<body>
 <div id="menu">
        <a href="indexGerente.php">
            <i class="fa fa-home"></i></i>
            <span>Página Inicial</span>
        </a>
        <a href="listarMusicas.php">
            <i class="fa fa-search"></i>
            <span>Listar Músicas</span>
        </a>
        <a href="adicionarMusicas.php">
        <i class="fa fa-music"></i>
            <span>Adicionar Músicas</span>
        </a>
        <a href="logoutGerente.php">
            <i class="fa fa-sign-out"></i>
            <span>Sair</span>
        </a>
    </div>
    <div class="container">
            
    <div class="card">  
    <?php
    foreach($musicas as $musica){
        echo "<tr>";
        ?><div class='listar'><?php
        echo "<td><img width=150px src='{$musica->getImagens()}'></td><br>";
        ?><div class='infossemimg'>
        <div class='infos'><?php
        echo "<td>{$musica->getNome()}</td><br>";
        echo "<td>{$musica->getArtista()}</td><br>";
        echo "<td>{$musica->getGenero()}</td><br>";
        echo "<td><span class='material-symbols-outlined'>favorite</span>{$musica->getSincronizacoes()}</td><br>";
        echo "<td><span class='material-symbols-outlined'>heart_broken</span>{$musica->getAssincronos()}</td><br>";
        
        ?>
        </div>
        <audio id="audio" controls src="<?php echo $musica->getAudio(); ?>" type="audio/mp3"></audio>
        <div class="editex">
        <?php
        echo "<td>
                <a class=btnf href='editarMusica.php?id={$musica->getId()}'>Editar</a>
                <a class=btnf href='deletarMusica.php?id={$musica->getId()}'>Excluir</a> 
             </td><br>";
        
        echo "</tr>";
        ?>
        </div>
        </div>
        </div>
        
        <?php
        
    }
    ?>
    </div>
    </div>
    <script>
        const menu = document.getElementById("menu");

        menu.addEventListener("mouseenter", () => {
            menu.style.width = "250px";
        });

        menu.addEventListener("mouseleave", () => {
            menu.style.width = "80px";
        });
    </script>
</body>
</html>

