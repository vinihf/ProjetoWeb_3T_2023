<?php
session_start();
if(!isset($_SESSION['id'])){
    header("location:loginGerente.php");
}
require_once __DIR__."/vendor/autoload.php";
$musica =  Musica::find($_GET['id']);
$musica->delete();
header("location:listarMusicas.php");
?>