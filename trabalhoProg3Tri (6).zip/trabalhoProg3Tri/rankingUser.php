<?php
session_start();
if(!isset($_SESSION['id'])){
    header("location:loginUser.php");
}
require_once __DIR__."/vendor/autoload.php";
$musicasSD = isset($_GET['id']) ? Musica::listarMusicasSincDesc($_GET['id']) : Musica::listarMusicasSincDesc();
$musicasSA = isset($_GET['id']) ? Musica::listarMusicasSincAsc($_GET['id']) : Musica::listarMusicasSincAsc();
$musicasAD = isset($_GET['id']) ? Musica::listarMusicasAssinDesc($_GET['id']) : Musica::listarMusicasAssinDesc();
$musicasAA = isset($_GET['id']) ? Musica::listarMusicasAssinAsc($_GET['id']) : Musica::listarMusicasAssinAsc();

?>
<!DOCTYPE html>
<html lang="pt-br">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Ranking</title>
    <link rel="shortcut icon" href="icon.png" />
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">
    <link rel="stylesheet" href="https://fonts.googleapis.com/css2?family=Material+Symbols+Outlined:opsz,wght,FILL,GRAD@20..48,100..700,0..1,-50..200" />
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.11.2/font/bootstrap-icons.min.css">
    <style>
         @import url('https://fonts.googleapis.com/css?family=Montserrat:400,800');

         body {
        background: #f6f5f7;
        padding-left: 90px;
        margin: 80px;
        font-family: 'Montserrat', sans-serif;
        display: flex;
        flex-direction: row;
    }

    .container {
        display: flex;
        flex-wrap: wrap;
        justify-content: space-around;
        align-items: flex-start;
    }

    .Sinc,
    .Assin {
        flex-basis: 38%; 
        margin: 10px;
        padding: 10px;
        background-color: white; /*divs Sinc */
        color: black;
    }

    .Assin {
        background-color: white; /* divs Assin */
    }

    .Sinc img,
    .Assin img {
        width: 100px;
        margin-bottom: 10px;
    }

    

        #menu {
            width: 80px;
            height: 100%;
            position: fixed;
            top: 0;
            left: 0;
            background-color: #f6f5f7;
            color: #7B1E83;
            overflow-x: hidden;
            transition: 0.5s;
            display: flex;
            flex-direction: column;
            align-items: center;
            justify-content: space-between;
        }

        #menu a {
            text-decoration: none;
            font-size: 16px;
            color: #7B1E83;
            display: flex;
            align-items: center;
            padding: 15px 0;
            transition: 0.3s;
        }

        #menu a:hover {
            border-radius: 40px;
            color: #f6f5f7;
            background-color: #7B1E83;
            padding: 12px;
        }

        #menu i {
            font-size: 24px;
            margin-bottom: 5px;
            margin-right: 8px;
            margin-left: 8px;
        }

        #menu span {
            display: none;
        }

        #menu:hover span {
            display: block;
        }

        #toggleButton{
            display: inline-block;
            padding: 8px 16px; 
            font-size: 14px;
            text-align: center;
            text-decoration: none;
            cursor: pointer;
            border: 2px solid #7B1E83; 
            border-radius: 5px;
            color: #7B1E83; 
            background-color: white;
            transition: background-color 0.3s, color 0.3s;
        }
        
        #toggleButton:hover {
            background-color: #7B1E83; 
            color: white;
        }

        h2{
        font-family: 'Montserrat', sans-serif;
        }
        
    </style>
</head>
<body>
    <!-- menu lateral -->
    <div id="menu">
        <a href="PaginaInicialUser.php">
            <i class="fa fa-home"></i>
            <span>Página Inicial</span>
        </a>
        <a href="rankingUser.php">
        <i class="bi bi-bar-chart-fill"></i>
        <span>Ranking</span>
        </a>
        <a href="editarContaUser.php">
        <i class="bi bi-pen-fill"></i>            
        <span>Editar conta</span>
        </a>
        <a href="logoutUser.php">
            <i class="fa fa-sign-out"></i>
            <span>Sair</span>
        </a>
    </div>
    <div class="container">
           <!--na fase do login precisamos criar uma conta com senha em hash para fazer a validacao-->
           <button id="toggleButton">Mostrar Mais</button>

        <div>
            <div class="Sinc">
                <h2>Mais Sincronizadas</h2>
                <?php
                    foreach ($musicasSD as $musicaSD) {
                        echo "<img width=150px src='{$musicaSD->getImagens()}'>"."<br>";
                        echo "{$musicaSD->getNome()}"."<br>";
                        echo "{$musicaSD->getArtista()}"."<br>";
                        echo "<span class='material-symbols-outlined'>favorite</span>{$musicaSD->getSincronizacoes()}<br>";
                        echo "<span class='material-symbols-outlined'>heart_broken</span>{$musicaSD->getAssincronos()}<br>";
                        echo "<br>";
                    }
                ?>
                
            </div>
            <div class="Assin">
                <h2>Mais Assincronizadas</h2>
                <?php
                    foreach ($musicasAD as $musica) {
                        echo "<img width=150px src='{$musica->getImagens()}'></"."<br><br>";
                        echo "{$musica->getNome()}"."<br>";
                        echo "{$musica->getArtista()}"."<br>";
                        echo "<span class='material-symbols-outlined'>heart_broken</span>{$musica->getAssincronos()}<br>";
                        echo "<span class='material-symbols-outlined'>favorite</span>{$musica->getSincronizacoes()}<br>";
                        echo "<br>";
                    }
                ?>
            </div>
            
        </div>
        <div></div>
            <div class="Sinc">
            <h2>Menos Sincronizadas</h2>

                <?php
                    foreach ($musicasSA as $musica) {
                        echo "<img width='150px' src='{$musica->getImagens()}'>"."<br>";
                        echo "{$musica->getNome()}"."<br>";
                        echo "{$musica->getArtista()}"."<br>";
                        echo "<span class='material-symbols-outlined'>favorite</span>{$musica->getSincronizacoes()}<br>";
                        echo "<span class='material-symbols-outlined'>heart_broken</span>{$musica->getAssincronos()}<br>";
                        echo "<br>";
                    }
                ?>
            </div>
            <div class="Assin">
            <h2>Menos Assincronizadas</h2>
                <?php
                    foreach ($musicasAA as $musica) {
                        echo "<img width=150px src='{$musica->getImagens()}'>"."<br>";
                        echo "{$musica->getNome()}"."<br>";
                        echo "{$musica->getArtista()}"."<br>";
                        echo "<span class='material-symbols-outlined'>heart_broken</span>{$musica->getAssincronos()}<br>";
                        echo "<span class='material-symbols-outlined'>favorite</span>{$musica->getSincronizacoes()}<br>";
                        echo "<br>";
                    }
                ?>
            </div>
            
            
            
        </div>
        
    </div>
    <script>
        const menu = document.getElementById("menu");

        menu.addEventListener("mouseenter", () => {
            menu.style.width = "250px";
        });

        menu.addEventListener("mouseleave", () => {
            menu.style.width = "80px";
        });

        const toggleButton = document.getElementById("toggleButton");
            const sincDivs = document.querySelectorAll(".Sinc");
            const assinDivs = document.querySelectorAll(".Assin");

            // aqui as classes "Assin" não aparecem
            assinDivs.forEach(div => {
                div.style.display = "none";
            });

            toggleButton.addEventListener("click", () => {
                // divs com classe "Sinc" e alterna a visibilidade
                sincDivs.forEach(div => {
                    div.style.display = div.style.display === "none" ? "block" : "none";
                });

                //  divs com classe "Assin" e alterna a visibilidade
                assinDivs.forEach(div => {
                    div.style.display = div.style.display === "none" ? "block" : "none";
                });
            });
    </script>
</body>
</html>
