<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8" />
  <meta name="viewport" content="width=device-width, initial-scale=1.0" />
  <title>Mini Player</title>
  <style>
    body {
  background: #dfe7ef;
  font-family: "Bitter", serif;
  margin: 0;
  padding: 0;
}

.wrapper {
  display: flex;
  align-items: center;
  justify-content: center;
  min-height: 100vh;
}

.player {
  background: #eef3f7;
  width: 410px;
  box-shadow: 0px 15px 35px -5px rgba(50, 88, 130, 0.32);
  border-radius: 15px;
  padding: 30px;
}

.player__top {
  display: flex;
  align-items: flex-start;
}

.player-cover {
  width: 300px;
  height: 300px;
  margin-left: -70px;
  border-radius: 15px;
}

.player-cover__item {
  background: #ccc; /* Placeholder color */
  width: 100%;
  height: 100%;
  border-radius: 15px;
}

.player-controls {
  flex: 1;
  padding-left: 20px;
  display: flex;
  flex-direction: column;
}

.player-controls__item {
  font-size: 30px;
  padding: 5px;
}

  </style>
</head>
<body>
  <div class="wrapper">
    <div class="player">
      <div class="player__top">
        <div class="player-cover">
          <div class="player-cover__item"></div>
        </div>
        <div class="player-controls">
          <div class="player-controls__item -favorite">
            <svg class="icon">
              <use xlink:href="#icon-heart-o"></use>
            </svg>
          </div>
          <a href="#" target="_blank" class="player-controls__item">
            <svg class="icon">
              <use xlink:href="#icon-link"></use>
            </svg>
          </a>
          <div class="player-controls__item">
            <svg class="icon">
              <use xlink:href="#icon-prev"></use>
            </svg>
          </div>
          <div class="player-controls__item">
            <svg class="icon">
              <use xlink:href="#icon-next"></use>
            </svg>
          </div>
          <div class="player-controls__item -xl js-play">
            <svg class="icon">
              <use xlink:href="#icon-play"></use>
            </svg>
          </div>
        </div>
      </div>
      <div class="progress">
        <div class="progress__top">
          <div class="album-info">
            <div class="album-info__name">Artist Name</div>
            <div class="album-info__track">Song Title</div>
          </div>
          <div class="progress__duration">3:30</div>
        </div>
        <div class="progress__bar"></div>
        <div class="progress__time">1:45</div>
      </div>
    </div>
  </div>
  <script src="https://code.iconify.design/1/1.0.7/iconify.min.js"></script>
</body>
</html>
