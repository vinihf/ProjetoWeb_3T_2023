<?php
session_start();
if(!isset($_SESSION['id'])){
    header("location:loginGerente.php");
}
if(isset($_GET['id'])){
    require_once __DIR__."/vendor/autoload.php";
    $musica = Musica::find($_GET['id']);
    //var_dump($musica);  verificação se está sendo carregada corretamente
}
if(isset($_POST['botao'])){
    require_once __DIR__."/vendor/autoload.php";
    //var_dump($_POST); 
    //var_dump($_FILES);


    $musica = new Musica($_POST['nome'],$_POST['artista'],$_POST['genero'],$_POST['sincronizacoes'],
    $_POST['assincronos'],$_FILES['imagens']['name'],$_FILES['audio']['name']);
    $musica->setId($_POST['id']);
    $musica->save();
    header("location: listarMusicas.php");
}
?>
<!DOCTYPE html>
<html lang="pt-br">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Editar Musicas</title>
    <link rel="shortcut icon" img href="icon.png" />
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">
    <style>
    @import url('https://fonts.googleapis.com/css?family=Montserrat:400,800');

        * {
            box-sizing: border-box;
        }

        body {
            background: #f6f5f7;
            display: flex;
            justify-content: center;
            align-items: center;
            flex-direction: column;
            font-family: 'Montserrat', sans-serif;
            height: 100vh;
            margin: -20px 0 50px;
        }
        
        .button {
            border-radius: 20px;
            border: 1px solid #ce2bff;
            background-color: #7B1E83;
            color: #FFFFFF;
            font-size: 12px;
            font-weight: bold;
            padding: 12px 45px;
           
        }

        form {
            background-color: #FFFFFF;
            padding: 50px 50px;
            height: 100%;
        }

        input {
            background-color: #eee;
            border: none;
            padding: 12px 15px;
            margin: 8px 0;
            width: 100%;
        }

        .container {
            background-color: #fff;
            border-radius: 10px;
            box-shadow: 0 14px 28px rgba(0,0,0,0.25), 
                    0 10px 10px rgba(0,0,0,0.22);
            position: relative;
            overflow: hidden;
            width: 420px;
            max-width: 100%;
            min-height: 480px;
        }

        #menu {
            width: 80px;
            height: 100%;
            position: fixed;
            top: 0;
            left: 0;
            background-color: #f6f5f7;
            color: #7B1E83;
            overflow-x: hidden;
            transition: 0.5s;
            display: flex;
            flex-direction: column;
            align-items: center;
            justify-content: space-between;
        }

        #menu a {
            text-decoration: none;
            font-size: 16px;
            color: #7B1E83;
            display: flex;
            align-items: center;
            padding: 15px 0;
            transition: 0.3s;
        }

        #menu a:hover {
            border-radius: 40px;
            color: #f6f5f7;
            background-color: #7B1E83;
            padding: 12px;
        }

        #menu i {
            font-size: 24px;
            margin-bottom: 5px;
            margin-right: 8px;
            margin-left: 8px;
        }

        #menu span {
            display: none;
        }

        #menu:hover span {
            display: block;
        }
    </style>
</head>
<body>
<div id="menu">
        <a href="indexGerente.php">
            <i class="fa fa-home"></i></i>
            <span>Página Inicial</span>
        </a>
        <a href="listarMusicas.php">
            <i class="fa fa-search"></i>
            <span>Listar Músicas</span>
        </a>
        <a href="adicionarMusicas.php">
        <i class="fa fa-music"></i>
            <span>Adicionar Músicas</span>
        </a>
        <a href="logoutGerente.php">
            <i class="fa fa-sign-out"></i>
            <span>Sair</span>
        </a>
    </div>
    <div class="container">
    <form action='editarMusica.php' method='POST' enctype="multipart/form-data">
        <?php
            echo "Nome: <input name='nome' value='{$musica->getNome()}' type='text' required>";
            echo"<br>";
            echo "Artista: <input name='artista' value={$musica->getArtista()} type='artista' required>";
            echo"<br>";
            echo "Gênero: <input name='genero' value='{$musica->getGenero()}' type='genero' required>";
            echo"<br>";
            echo "Imagem: <input name='imagens' value='{$musica->getImagens()}' type='file' accept='.png' >";
            echo"<br>";
            echo "Áudio: <input name='audio' value='{$musica->getAudio()}' type='file' accept='.mp3' >";
            echo"<br>";
            echo "<input name='sincronizacoes' value='{$musica->getSincronizacoes()}' type='hidden'>";            
            echo "<input name='assincronos' value='{$musica->getAssincronos()}' type='hidden'>";
            echo "<input name='id' value={$musica->getId()} type='hidden'>";
            echo "<br>";
            echo "<input type='submit' class='button' name='botao'>";
        ?>
    </form>
    </div>
    <script>
        const menu = document.getElementById("menu");

        menu.addEventListener("mouseenter", () => {
            menu.style.width = "250px";
        });

        menu.addEventListener("mouseleave", () => {
            menu.style.width = "80px";
        });
    </script>
</body>
</html>