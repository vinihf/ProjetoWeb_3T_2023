<?php
session_start();
if(!isset($_SESSION['id'])){
    header("location:loginUser.php");
}

require_once __DIR__."/vendor/autoload.php";
$musicas = Musica::chamaMusicaRandom($_SESSION['id']);
//$musicas = isset($_GET['id']) ? Musica::chamaMusicaRandom($_GET['id']) : Musica::chamaMusicaRandom();


if (empty($musicas)) {
    // quando não tiver mais músicas
    echo "<div style='position: absolute; top: 50%; left: 50%; transform: translate(-50%, -50%); text-align: center;'>";
    echo "<p style='font-size: 36px; color: #7B1E83; font-weight: bold;'>";
    echo "Você já avaliou todas as músicas! <span style='font-size: 40px;'>😊</span></p></div>";       
} else {
    if (isset($_POST['Sync'])) {
        $us = new Usuariosyncs($_POST['idM'], $_SESSION['id'], "S");
        $us->save();
    }

    if (isset($_POST['Assinc'])) {
        $us = new Usuariosyncs($_POST['idM'], $_SESSION['id'], "A");
        $us->save();
    }
}
?>



<!DOCTYPE html>
<html lang="pt-br">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Página Inícial</title>
    <link rel="shortcut icon" href="icon.png"/>
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">
    <link rel="stylesheet" href="https://fonts.googleapis.com/css2?family=Material+Symbols+Outlined:opsz,wght,FILL,GRAD@20..48,100..700,0..1,-50..200">
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.11.2/font/bootstrap-icons.min.css">

    <style> 
  
  @import url('https://fonts.googleapis.com/css2?family=DM+Sans:opsz,wght@9..40,300&display=swap');
  @import url('https://fonts.googleapis.com/css2?family=Josefin+Sans:ital,wght@1,700&family=Pathway+Gothic+One&display=swap');

  @import url('https://fonts.googleapis.com/css2?family=Hedvig+Letters+Serif:opsz@12..24&display=swap');

 #menu {
            width: 80px;
            height: 100%;
            position: fixed;
            top: 0;
            left: 0;
            background-color: #f6f5f7;
            color: #7B1E83;
            overflow-x: hidden;
            transition: 0.5s;
            display: flex;
            flex-direction: column;
            align-items: center;
            justify-content: space-between;
        }

        #menu a {
            text-decoration: none;
            font-size: 16px;
            color: #7B1E83;
            display: flex;
            align-items: center;
            padding: 15px 0;
            transition: 0.3s;
        }

        #menu a:hover {
            border-radius: 40px;
            color: #f6f5f7;
            background-color: #7B1E83;
            padding: 12px;
        }

        #menu i {
            font-size: 24px;
            margin-bottom: 5px;
            margin-right: 8px;
            margin-left: 8px;
        }

        #menu span {
            display: none;
        }

        #menu:hover span {
            display: block;
        }

         body {
            background: #f6f5f7;
            margin: 0;
            padding: 0;
            font-family: 'Montserrat', sans-serif;
            display: flex;
            flex-direction: column;
            align-items: center;
            justify-content: center;
            height: 100vh;
	        margin: 0 50px;
        }

        .container {
            background-color: #fff;
            border-radius: 10px;
            box-shadow: 0 14px 28px rgba(0,0,0,0.25), 
                    0 10px 10px rgba(0,0,0,0.22);
            position: relative;
            overflow: hidden;
            width: 420px;
            max-width: 100%;
            min-height: 480px;
            /*display: flex;
            flex-wrap: wrap;
            justify-content: space-around;
            align-items: flex-start;
            margin: 80px 0 0 90px; /* Adicione a margem no top, para manter o espaço do menu */
        }

        .centered-image {
            width: 250px;
            border-radius: 10px;
            box-shadow: 0 14px 28px rgba(0,0,0,0.25), 0 10px 10px rgba(0,0,0,0.22);
            display: block;
            margin-left: auto;
            margin-right: auto;
            margin-top: 5%;
        }

    .nome-musica {
        font-family: 'Pathway Gothic One', sans-serif; 
        font-size: 30px;
    }

    .artista {
        color: #393d3f;
        font-size: 20px;
        font-family: 'Hedvig Letters Serif', serif;
    }

    .infossemimg{
        display: flex;
        justify-content: space-between;
        margin-left: 5%;
        margin-right: 5%;    
        text-justify: distribute;    
    }

    .noart{
        display: flex;
        flex-direction: column;
        align-items: center;
        align-self: center;
        }

    .divaudio{
        display: flex;
        justify-content: center;
        margin: 5%;
    }
    
    #audio {
        width: 100%; 
        background: transparent;
        border: none;
        outline: none;
        font-family: 'Pathway Gothic One', sans-serif;
        color: black; 
    }

/* Estilizando os controles do player */
#audio::-webkit-media-controls-panel {
  background: transparent; /* Fundo dos controles transparente para navegadores WebKit (Chrome, Safari) */
}

#audio::-webkit-media-controls-enclosure {
  background: transparent; 

}

.iconBotao span {
  font-size: 39px;
 
}


.iconBotao span:hover {
    border-radius: 50%;
    transition: color 0.3s, border-color 0.3s;
    color: #f6f5f7;
    background-color: #8B0000;
    padding: 9px;

}



    </style>
</head>
<body>
    <!-- menu lateral -->
    <div id="menu">
        <a href="PaginaInicialUser.php">
            <i class="fa fa-home"></i>
            <span>Página Inicial</span>
        </a>
        <a href="rankingUser.php">
            <i class="bi bi-bar-chart-fill"></i>
            <span>Ranking</span>
        </a>
        <a href="editarContaUser.php">
            <i class="bi bi-pen-fill"></i>            
            <span>Editar conta</span>
        </a>
        <a href="logoutUser.php">
          <i class="fa fa-sign-out"></i>
          <span>Sair</span>
        </a>
    </div>
    <?php
    if(!empty($musicas)){
        ?>
    <div class="container">
    <form method="post" action="PaginaInicialUser.php">
    <?php
        
            foreach($musicas as $musica){
                ?>
                <div class='listar'><?php
                    echo "<img class='centered-image' src='{$musica->getImagens()}'><br>";
                ?><div class='infossemimg'><?php
                //echo "<input type='submit' name='Assinc' id='descurtirButton'>"; 
                echo "<button type='submit' name='Assinc' id='descurtirButton'  class='iconBotao' style=' color: #8B0000; border: none; background: none;'><span class='material-symbols-outlined'>heart_broken</span></button>";
                ?><div class="noart">
                    <?php
                    echo "<p class='nome-musica'>{$musica->getNome()}</p>";
                    echo "<p class='artista'>{$musica->getArtista()}</p>";?>
                </div>
                <?php
                echo "<input type='hidden' name='idM' value='{$musica->getId()}'>";
                echo "<button type='submit' name='Sync' id='curtirButton'  class='iconBotao' style=' color: #8B0000; border: none; background: none;'><span class='material-symbols-outlined'>favorite</span></button>";
                // <button type="submit"><i class="fa fa-plus"></i> Cadastrar</button>
                }
                ?></div>
                <div class= 'divaudio'>
                <audio  autoplay="autoplay" controls="controls" id="audio"  src="<?php echo $musica->getAudio(); ?>" type="audio/mp3" ></audio>
                </div><?php
        }
        
    ?>
    </form>

    </div>
   

    <script>
     const menu = document.getElementById("menu");

        menu.addEventListener("mouseenter", () => {
            menu.style.width = "250px";
        });

        menu.addEventListener("mouseleave", () => {
            menu.style.width = "80px";
        });
    </script>
</body>
</html>