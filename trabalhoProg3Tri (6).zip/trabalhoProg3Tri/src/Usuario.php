<?php
class Usuario implements ActiveRecord{

    private int $id;
    private string $nome; 
    private string $email;

    public function __construct(private string $senha){
    }

    public function setId(int $id):void{
        $this->id = $id;
    }

    public function getId():int{
        return $this->id;
    }


    public function setNome(string $nome):void{
        $this->nome = $nome;
    }

    public function getNome():string{
        return $this->nome;
    }
    
    public function setSenha(string $senha):void{
        $this->senha = $senha;
    }

    public function getSenha():string{
        return $this->senha;
    }

    public function setEmail(string $email):void{
        $this->email = $email;
    }

    public function getEmail():string{
        return $this->email;
    }
   


    public function save():bool{
        $conexao = new MySQL();
        if(isset($this->id)){
            $sql = "UPDATE usuario SET nome = '{$this->nome}' , senha = '" . password_hash($this->senha, PASSWORD_DEFAULT) . "' WHERE id = {$this->id}";
        }else{
            $sql = "INSERT INTO usuario (nome,email,senha) VALUES ('{$this->nome}','{$this->email}','" . password_hash($this->senha, PASSWORD_DEFAULT) . "')";
        }
        return $conexao->executa($sql);
        
    }
    public function delete():bool{
        $conexao = new MySQL();
        $sql = "DELETE FROM usuario WHERE id = {$this->id}";
        return $conexao->executa($sql);
    }

    public static function find($id):Usuario{
        $conexao = new MySQL();
        $sql = "SELECT * FROM usuario WHERE id = {$id}";
        $resultado = $conexao->consulta($sql);
        $p = new Usuario($resultado[0]['senha']);
        $p->setEmail($resultado[0]['email']);
        $p->setNome($resultado[0]['nome']);
        $p->setId($resultado[0]['id']);
        return $p;
    }
    public static function findall():array{
        $conexao = new MySQL();
        $sql = "SELECT * FROM usuario";
        $resultados = $conexao->consulta($sql);
        $usuarios = array();
        foreach($resultados as $resultado){
            $p = new Usuario($resultado[0]['senha']);
            $p->setEmail($resultado[0]['email']);
            $p->setNome($resultado[0]['nome']);
            $p->setId($resultado['id']);
            $usuarios[] = $p;
        }
        return $usuarios;
    }

    public function authenticate():bool{
        $conexao = new MySQL();
        $sql = "SELECT id, nome, email, senha FROM usuario WHERE email = '{$this->email}'";
        $resultados = $conexao->consulta($sql);
        if(password_verify($this->senha,$resultados[0]['senha'])){
            session_start();
            $_SESSION['id'] = $resultados[0]['id'];
            //$_SESSION['nome'] = $resultados[0]['nome'];
            $_SESSION['email'] = $resultados[0]['email'];
            return true;
        }else{
            return false;
        }
    }
}
