<?php
class UsuarioSyncs implements ActiveRecord{

    private int $id;


    public function __construct(private int $idMusica, private int $idUsuario, private string $status){
    }

    public function setId(int $id):void{
        $this->id = $id;
    }

    public function getId():int{
        return $this->id;
    }

    public function setIdMusica(int $idMusica):void{
        $this->idMusica = $idMusica;
    }

    public function getIdMusica():int{
        return $this->idMusica;
    }

    public function setIdUsuario(int $idUsuario):void{
        $this->idUsuario = $idUsuario;
    }

    public function getIdUsuario():int{
        return $this->idUsuario;
    }

    public function setStatus(int $status):void{
        $this->status = $status;
    }

    public function getStatus():string{
        return $this->status;
    }

    
    public function save():bool{
        $conexao = new MySQL();
        $sql = "INSERT INTO usuariosyncs (idMusica, idUsuario, status) VALUES ('{$this->idMusica}','{$this->idUsuario}','{$this->status}')";
        return $conexao->executa($sql);
        
    }
    public function delete():bool{
        $conexao = new MySQL();
        $sql = "DELETE FROM usuariosyncs WHERE id = {$this->id}";
        return $conexao->executa($sql);
    }

    public static function find($id):Usuariosyncs{
        $conexao = new MySQL();
        $sql = "SELECT * FROM usuariosyncs WHERE id = {$id}";
        $resultado = $conexao->consulta($sql);
        $p = new Usuariosyncs($resultado[0]['idMusica'], $resultado[0]['idUsuario'], $resultado[0]['status']);
        return $p;
    }
    public static function findall():array{
        $conexao = new MySQL();
        $sql = "SELECT * FROM usuariosyncs";
        $resultados = $conexao->consulta($sql);
        $usuarios = array();
        foreach($resultados as $resultado){
            $p = new Usuariosyncs($resultado[0]['idMusica'], $resultado[0]['idUsuario'], $resultado[0]['status']);
            $p->setId($resultado['id']);
            $usuarios[] = $p;
        }
        return $usuarios;
    }
}
