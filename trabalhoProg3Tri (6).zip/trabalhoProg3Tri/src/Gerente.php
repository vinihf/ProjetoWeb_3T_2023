<?php
class Gerente implements ActiveRecord{

    private int $id;

    public function __construct(private string $user, private string $senha){
    }

    public function setId(int $id):void{
        $this->id = $id;
    }

    public function getId():int{
        return $this->id;
    }


    public function setUser(string $user):void{
        $this->user = $user;
    }

    public function getUser():string{
        return $this->user;
    }

    public function setSenha(string $senha):void{
        $this->senha = $senha;
    }

    public function getSenha():string{
        return $this->senha;
    }
   


    public function save(): bool {
        $conexao = new MySQL();
        if (isset($this->id)) {
            $sql = "UPDATE gerente SET user = '{$this->user}' ,senha = '" . password_hash($this->senha, PASSWORD_DEFAULT) . "' WHERE id = {$this->id}";
        } else {
            $sql = "INSERT INTO gerente (user, senha) VALUES ('{$this->user}', '" . password_hash($this->senha, PASSWORD_DEFAULT) . "')";
        }
        return $conexao->executa($sql);
    }
    
    public function delete():bool{
        $conexao = new MySQL();
        $sql = "DELETE FROM gerente WHERE id = {$this->id}";
        return $conexao->executa($sql);
    }

    public static function find($id):Gerente{
        $conexao = new MySQL();
        $sql = "SELECT * FROM gerente WHERE id = {$id}";
        $resultado = $conexao->consulta($sql);
        $p = new Gerente($resultado[0]['user'],$resultado[0]['senha']);
        $p->setId($resultado[0]['id']);
        return $p;
    }
    public static function findall():array{
        $conexao = new MySQL();
        $sql = "SELECT * FROM gerente";
        $resultados = $conexao->consulta($sql);
        $gerentes = array();
        foreach($resultados as $resultado){
            $p = new Gerente($resultado['user'],$resultado['senha']);
            $p->setId($resultado['id']);
            $gerentes[] = $p;
        }
        return $gerentes;
    }
    
    public function authenticate():bool{
        $conexao = new MySQL();
        $sql = "SELECT id,user,senha FROM gerente WHERE user = '{$this->user}'";
        $resultados = $conexao->consulta($sql);
        if(password_verify($this->senha,$resultados[0]['senha'])){
            session_start();
            $_SESSION['id'] = $resultados[0]['id'];
            $_SESSION['user'] = $resultados[0]['user'];
            return true;
        }else{
            return false;
        }
    }
}