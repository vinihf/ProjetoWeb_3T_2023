<?php

class Musica implements ActiveRecord{

    private int $id;



    public function __construct(
        private string $nome,
        private string $artista,
        private string $genero,
        private string $sincronizacoes,
        private string $assincronos,
        private array|string $imagens,
        private array|string $audio
    )
    
    {
    }

    public function setId(int $id):void{
        $this->id = $id;
    }

    public function getId():int{
        return $this->id;
    }

    public function setNome(string $nome):void{
        $this->nome = $nome;
    }

    public function getNome():string{
        return $this->nome;
    }

    public function setArtista(string $artista):void{
        $this->artista = $artista;
    }

    public function getArtista():string{
        return $this->artista;
    }

    public function setGenero(string $genero):void{
        $this->genero = $genero;
    }

    public function getGenero():string{
        return $this->genero;
    }

    public function setSincronizacoes(string $sincronizacoes):void{
        $this->sincronizacoes = $sincronizacoes;
    }

    public function getSincronizacoes():string{
        return $this->sincronizacoes;
    }

    public function setAssincronos(string $assincronos):void{
        $this->assincronos = $assincronos;
    }

    public function getAssincronos():string{
        return $this->assincronos;
    }

    public function setImagens(string $imagens):void{
        $this->imagens = $imagens;
    }

    public function getImagens():string{
        return $this->imagens;
    }

    public function setAudio(string $audio):void{
        $this->audio = $audio;
    }

    public function getAudio():string{
        return $this->audio;
    }

    public function save():bool{
        $conexao = new MySQL();

        /*// Diretório para imagens
        $diretorioImagens = __DIR__ . "/imagens/";
        if (!file_exists($diretorioImagens)) {
            mkdir($diretorioImagens, 0777, true);
        }

        // Diretório para áudio
        $diretorioAudio = __DIR__ . "/musicas/";
        if (!file_exists($diretorioAudio)) {
            mkdir($diretorioAudio, 0777, true);
        }

        // Manipulação de imagens
        $nome_arquivoImagens = $this->imagens;
        $info_nameImagens = pathinfo($nome_arquivoImagens);  
        $extensaoImagens = $info_nameImagens['extension'];
        $this->imagens = $diretorioImagens . uniqid() . "." . $extensaoImagens;
        move_uploaded_file($_FILES["imagens"]["tmp_name"], $this->imagens);

        // Manipulação de áudio
        $nome_arquivoAudio = $this->audio;
        $info_nameAudio = pathinfo($nome_arquivoAudio);  
        $extensaoAudio = $info_nameAudio['extension'];
        $this->audio = $diretorioAudio . uniqid() . "." . $extensaoAudio;
        move_uploaded_file($_FILES["audio"]["tmp_name"], $this->audio);*/
        
        $conexao = new MySQL();

        // Diretório para imagens (caminho relativo)
        $diretorioImagens = "imagens/";
        if (!file_exists($diretorioImagens)) {
            mkdir($diretorioImagens, 0777, true);
        }

        // Diretório para áudio (caminho relativo)
        $diretorioAudio = "musicas/";
        if (!file_exists($diretorioAudio)) {
            mkdir($diretorioAudio, 0777, true);
        }

        $nome_arquivoImagens = $this->imagens;
        $info_nameImagens = pathinfo($nome_arquivoImagens);  
        $extensaoImagens = $info_nameImagens['extension'];
        $this->imagens = $diretorioImagens . uniqid() . "." . $extensaoImagens;
        move_uploaded_file($_FILES["imagens"]["tmp_name"], $this->imagens);
        $nome_arquivoAudio = $this->audio;
        $info_nameAudio = pathinfo($nome_arquivoAudio);  
        $extensaoAudio = $info_nameAudio['extension'];
        $this->audio = $diretorioAudio . uniqid() . "." . $extensaoAudio;
        move_uploaded_file($_FILES["audio"]["tmp_name"], $this->audio);

        if (isset($this->id)) {
            $sql = "UPDATE musica SET nome = '{$this->nome}', artista = '{$this->artista}', genero = '{$this->genero}',
                sincronizacoes = '{$this->sincronizacoes}', assincronos = '{$this->assincronos}', 
                imagens = '{$this->imagens}', audio = '{$this->audio}' WHERE id = {$this->id}";
        } else {
            $sql = "INSERT INTO musica (nome, artista, genero, sincronizacoes, assincronos, imagens, audio) 
            VALUES ('{$this->nome}', '{$this->artista}', '{$this->genero}', '{$this->sincronizacoes}', '{$this->assincronos}',
            '{$this->imagens}', '{$this->audio}')";
        }

        return $conexao->executa($sql);
        
    }
        
        public function delete():bool{
            $conexao = new MySQL();
            $sql = "DELETE FROM musica WHERE id = {$this->id}";
            return $conexao->executa($sql);
        }
    
        public static function find($id):Musica{
            $conexao = new MySQL();
            $sql = "SELECT * FROM musica WHERE id = {$id}";
            $resultado = $conexao->consulta($sql);
            $p = new Musica($resultado[0]['nome'],$resultado[0]['artista'],$resultado[0]['genero'],
            $resultado[0]['sincronizacoes'],$resultado[0]['assincronos'],$resultado[0]['imagens'],
            $resultado[0]['audio']);
            $p->setId($resultado[0]['id']);
            return $p;
        }
        public static function findall():array{
            $conexao = new MySQL();
            $sql = "SELECT * FROM musica";
            $resultados = $conexao->consulta($sql);
            $musicas = array();
            foreach ($resultados as $resultado) {
            $musica = new Musica(
                    $resultado['nome'],
                    $resultado['artista'],
                    $resultado['genero'],
                    $resultado['sincronizacoes'],
                    $resultado['assincronos'],
                    $resultado['imagens'],
                    $resultado['audio']
                );            
                $musica->setId($resultado['id']);
                $musicas[] = $musica;
            }
            return $musicas;
        }
        
        public static function listarMusicasSincAsc():array {
            $conexao = new MySQL();
            $sql = "SELECT * FROM musica ORDER BY sincronizacoes ASC";
        
            $resultados = $conexao->consulta($sql);
            $musicas = array();
            foreach ($resultados as $resultado) {
            $musica = new Musica(
                    $resultado['nome'],
                    $resultado['artista'],
                    $resultado['genero'],
                    $resultado['sincronizacoes'],
                    $resultado['assincronos'],
                    $resultado['imagens'],
                    $resultado['audio']
                );            
                $musica->setId($resultado['id']);
                $musicas[] = $musica;
            }
            return $musicas;
        }
        
       
        
        public static function listarMusicasSincDesc():array {
            $conexao = new MySQL();
            $sql = "SELECT * FROM musica ORDER BY sincronizacoes DESC";
        
            $resultados = $conexao->consulta($sql);
            $musicas = array();
            foreach ($resultados as $resultado) {
            $musica = new Musica(
                    $resultado['nome'],
                    $resultado['artista'],
                    $resultado['genero'],
                    $resultado['sincronizacoes'],
                    $resultado['assincronos'],
                    $resultado['imagens'],
                    $resultado['audio']
                );            
                $musica->setId($resultado['id']);
                $musicas[] = $musica;
            }
            return $musicas;
         }
        
        public static function listarMusicasAssinAsc():array {
            $conexao = new MySQL();
            $sql = "SELECT * FROM musica ORDER BY assincronos ASC";
        
            $resultados = $conexao->consulta($sql);
            $musicas = array();
            foreach ($resultados as $resultado) {
            $musica = new Musica(    
                $resultado['nome'],
                $resultado['artista'],
                $resultado['genero'],
                $resultado['sincronizacoes'],
                $resultado['assincronos'],
                $resultado['imagens'],
                $resultado['audio']
             );            
                $musica->setId($resultado['id']);
                $musicas[] = $musica;
            }
            return $musicas;
        }
    
        public static function listarMusicasAssinDesc():array {
            $conexao = new MySQL();
            $sql = "SELECT * FROM musica ORDER BY assincronos DESC";
        
            $resultados = $conexao->consulta($sql);
            $musicas = array();
            foreach ($resultados as $resultado) {
            $musica = new Musica(    
                $resultado['nome'],
                $resultado['artista'],
                $resultado['genero'],
                $resultado['sincronizacoes'],
                $resultado['assincronos'],
                $resultado['imagens'],
                $resultado['audio']
             );            
                $musica->setId($resultado['id']);
                $musicas[] = $musica;
            }
            return $musicas;
        }

        public static function chamaMusicaRandom($uId):array {
            $conexao = new MySQL();
            $sql = "SELECT * FROM musica WHERE id NOT IN 
            (SELECT idMusica FROM usuariosyncs WHERE idUsuario = $uId) ORDER BY rand() limit 1 ";
        
            $resultados = $conexao->consulta($sql);
            $musicas = array();
            foreach ($resultados as $resultado) {
            $musica = new Musica(    
                $resultado['nome'],
                $resultado['artista'],
                $resultado['genero'],
                $resultado['sincronizacoes'],
                $resultado['assincronos'],
                $resultado['imagens'],
                $resultado['audio']
             );            
                $musica->setId($resultado['id']);
                $musicas[] = $musica;
            }
            return $musicas;
        }
        
    }

